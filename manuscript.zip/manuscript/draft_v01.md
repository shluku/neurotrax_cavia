# Draft v0.2

## Building and Testing an Auditable Patient-Level Digital Phenotype of Cognition from Passive Smartphone Sensing: An Exploratory Proof-of-Concept Study

**Authors:** [TO COMPLETE]

**Affiliations:** [TO COMPLETE]

**Target journal:** [TO COMPLETE]

> Working manuscript for supervisor review. Bracketed text marks information that must be verified or decided before submission.

## Abstract

### Background

Passive smartphone sensing may provide repeated behavioral information outside the clinic. However, raw sensor records do not constitute a clinical phenotype. They must be converted into interpretable patient-level measurements while accounting for different devices, observation periods, missing records, and uneven data availability. In a small cohort, the analytical process itself can strongly influence the apparent result.

### Objective

The study had two objectives: (1) to develop and audit an interpretable patient-level digital phenotype of baseline cognition and test whether it could estimate the participant's baseline cognitive score; and (2) to conduct an exploratory attempt to predict cognitive decline using baseline digital features and, in a later longitudinal analysis, changes in digital behavior between baseline and follow-up assessments. The present manuscript reports the development and initial baseline-score modeling for Objective 1. The decline-prediction objective is described as a planned extension rather than a completed clinical prediction result.

### Methods

We performed a retrospective computational analysis of an existing cohort with standardized computerized cognitive assessments and passively collected smartphone and sensor records. The data were generated during ordinary participant use rather than during a controlled behavioral experiment. Over several months, we implemented and reviewed a large collection of feature-extraction routines, quality-control checks, feature definitions, observation-window rules, and interpretable model variants. A curated patient-level feature library was then linked to baseline cognitive scores. We summarized coverage and missingness, screened candidate features using an exploratory median split of baseline cognitive score, and compared regularized Ridge models with a common mean baseline using repeated five-fold cross-validation.

### Results

The working cohort included 81 participants with observed baseline global cognitive scores. Sixty-one measured digital features were available for the exploratory feature comparison, including 54 features with completed metadata. Data availability varied substantially across participants and feature families. The five leading exploratory candidates were two keyboard-timing measures and three call-related measures. The two keyboard measures had nominal p-values of 0.032 and 0.036, but neither remained significant after false-discovery-rate correction. The primary 37-feature Ridge model performed similarly to the mean baseline rather than producing a clinically useful estimate. A narrow direction-constrained model built from the two strongest keyboard candidates showed a small numerical improvement but remained weak and exploratory.

### Conclusions

This study demonstrates the feasibility of building an auditable patient-level digital phenotyping workflow from heterogeneous passive smartphone records. It does not establish a clinically validated cognitive score. The main proof-of-concept result is that transparent feature construction, coverage auditing, manual curation, and baseline-referenced modeling can expose the limits of a small real-world dataset and provide a structured foundation for future validation.

**Keywords:** digital phenotyping; passive sensing; dementia research; cognitive assessment; missing data; data coverage; proof of concept; patient-level modeling

## 1. Introduction

Digital phenotyping aims to describe an individual's behavior, functioning, or health-related state using data generated during everyday life. Passive smartphone sensing is attractive for this purpose because phones can record patterns of interaction, typing, screen use, communication, activity, and other signals without requiring a separate measurement session for every observation. In cognitive research, these data may eventually complement clinic-based assessments by providing information about behavior between visits.

The practical challenge is that raw sensor data are not directly comparable to a cognitive score. A database row may represent a real behavioral event, a device status update, a duplicated observation, or a system-generated record. A missing row may mean no behavior, no phone use, a disabled sensor, a device change, an unavailable table, or a technical failure. A patient may contribute data from more than one device. One feature may be available for almost everyone while another is observed in only a small subgroup. These issues affect both the meaning of the feature and the validity of a patient-level model.

The challenge becomes more serious when the cohort is small. With a limited number of participants, a feature can appear associated with cognitive performance because of a small subgroup, uneven coverage, or chance. A feature-level group difference does not automatically become a useful prediction for a new patient. Similarly, adding more features can increase the amount of imputation and coefficient instability without adding independent information. A responsible proof-of-concept study must therefore describe the complete path from raw records to analyzed features and must compare models with a simple reference baseline.

The present work was conducted as a retrospective computational proof of concept. The participants were not assigned an intervention, instructed to change their phone behavior, or measured under laboratory conditions. Instead, the analysis used existing standardized computerized cognitive assessments and passively collected smartphone records generated during ordinary use. The computational experiment consisted of defining observation windows around the assessments, translating raw records into interpretable aggregate features, auditing data availability, selecting candidate features, and testing whether those features could estimate baseline cognition.

The work also had an important process component. Over several months, the project developed and reviewed hundreds of feature calculations and analysis variants. These included event counts, proportions, diversity measures, timing summaries, state transitions, device-level quality checks, table-level coverage checks, patient-level feature matrices, multiple observation windows, and several model families. The purpose of this extensive development was not to present every variant as an independent statistical test. It was to discover which calculations were technically meaningful, reproducible, sufficiently covered, and understandable enough to be considered for a patient-level phenotype.

This process is related to a wider scientific principle: the reliability of a result depends on how it is measured and reproduced, not only on whether one statistical test produces a small p-value. Large reproducibility projects demonstrated that variation in findings across samples and settings can itself be an important scientific result [1,2]. In another field, a search that did not identify a confirmed signal still produced valuable sensitivity limits and scientifically useful boundaries [3]. Recent digital-health protocols similarly distinguish feasibility, exploratory associations, and later validation rather than treating a small pilot as a clinically validated prediction model [4].

The study had two objectives. **Objective 1 was to create and test an interpretable, coverage-aware patient-level baseline digital phenotype** from passive smartphone records aligned with the baseline cognitive assessment, including an exploratory test of whether the phenotype could estimate the participant's baseline cognitive score. **Objective 2 was to explore whether digital phenotyping could help predict cognitive decline**, using baseline digital features and, in the longitudinal extension, changes in digital behavior between baseline and follow-up assessments. The present paper reports the baseline phenotype and initial baseline-score modeling while establishing the analytical foundation for Objective 2; it does not present decline prediction as completed or clinically validated.

The aim of this paper is therefore deliberately broader than asking whether one model predicts one score. We describe how a patient-level digital phenotype was constructed, how candidate features were curated and evaluated, what the available data supported, and where the current dataset reached its limits. The intended product is a candidate phenotype framework and an auditable analysis protocol, not a diagnostic tool or a validated clinical score.

## 2. Study setting and computational experiment

### 2.1 Retrospective naturalistic setting

This study used an existing research cohort containing standardized computerized cognitive assessments and passive smartphone and sensor records. The cognitive assessments provided a baseline score and, for a subset of participants, a later repeat score. The passive records were generated by ordinary phone use over the observation period. They were not collected in a laboratory, and participants were not assigned a fixed schedule of phone tasks for this analysis.

The computational experiment was performed after data collection. It consisted of five connected activities:

1. Link assessment records to participant and device identifiers.
2. Define a reproducible time window for the baseline phenotype.
3. Convert eligible raw records into interpretable patient-level features.
4. Audit the availability, missingness, and meaning of those features.
5. Compare candidate phenotype models with a common reference prediction.

### Study objectives

**Objective 1: Create and test a baseline digital phenotype.** Develop and audit a patient-level, interpretable, coverage-aware representation of passive smartphone behavior aligned with baseline cognitive performance, and conduct an exploratory test of whether the phenotype can estimate the participant's baseline cognitive score. The first-valid 24-hour observation within the first week after baseline is used for exploratory feature finding, after which finalized features can be applied to broader patient-level baseline analyses.

**Objective 2: Explore prediction of cognitive decline.** Test whether the baseline digital phenotype, and later changes in digital behavior between baseline and follow-up assessments, can help predict decline in cognitive performance. This is a planned exploratory longitudinal objective and is not presented as completed or clinically validated in this manuscript.

This setting is important for interpretation. The study evaluates whether an analysis pipeline can make useful measurements from real-world records. It does not estimate the effect of an intervention, and it does not prove that any sensor feature causes or directly reflects cognitive performance.

### 2.2 Participants and cognitive outcomes

The working baseline cohort included 81 participants with observed global cognitive scores at the first computerized assessment. The cohort's diagnostic composition, recruitment setting, inclusion criteria, consent procedures, and ethics approval information must be inserted after confirmation from the study team.

**[TO COMPLETE: ethics committee name and approval number; consent procedure; diagnostic categories; recruitment dates; inclusion and exclusion criteria; country and clinical setting.]**

The first assessment is referred to below as the **baseline assessment**. A later assessment, when available, is referred to as the **follow-up assessment**. This terminology is used instead of internal database labels so that the manuscript remains understandable to readers who do not know the project structure. In this paper, a patient-level feature means one summarized measurement for one participant over the defined observation window.

The primary outcome was the continuous global cognitive score at baseline. Secondary outcomes included available cognitive domains, including memory, executive function, processing speed, attention, and motor performance. The follow-up assessment was retained for future longitudinal analyses, but this first manuscript focuses on construction and evaluation of the baseline phenotype.

### 2.3 Development of the analysis pipeline

The analysis was developed iteratively over several months. The development sequence moved from raw-table inspection to feature review, extraction, quality control, and modeling. At each stage, outputs were saved as reviewable files rather than being overwritten by the next experiment.

The development work included hundreds of feature calculations and algorithmic variants. These variants differed in the way they identified valid records, handled duplicate observations, summarized high-frequency events, pooled device episodes, defined an observation window, or represented missing data. Other variants tested feature subsets, domain-specific feature groups, direction-constrained estimates, regularized models, alternative observation spans, and different visualization formats.

The analysis process used three types of selection:

- **Technical selection:** whether a calculation could be executed reproducibly and whether its result was numerically coherent.
- **Interpretability selection:** whether the feature had a clear behavioral meaning that could be explained to a clinical reader.
- **Coverage selection:** whether enough participants had observed values for the feature to make it suitable for the current proof of concept.

After this curation, a smaller feature library was carried forward. Outcome-informed screening was then performed as a separate exploratory step. This distinction is important because a feature selected after looking at the outcome can be useful for hypothesis generation but cannot be treated as an independently validated predictor.

### 2.4 Feature-finding and patient-level baseline windows

The initial feature-finding rule was the first valid 24-hour observation found within the first week after the baseline assessment. This short, availability-aware window was used to search for interpretable candidate features while keeping the feature-finding protocol close to the assessment.

After feature definitions were selected, the finalized features could be applied to broader patient-level baseline analyses. The main proof-of-concept baseline analysis in this manuscript used a midpoint-anchored observation window. For participants with both a baseline and follow-up assessment, this window began at baseline and ended at the midpoint between the two assessment dates. For participants without a valid follow-up date, a documented fallback duration of approximately 123 days was used.

The broader window was chosen to use more available real-world data and reduce missingness. It should therefore be understood as a **baseline-to-midpoint behavioral summary**, not as a measurement limited to the exact day of the cognitive assessment. The exact start date, end date, interval duration, and fallback provenance were retained for audit. Keeping feature finding and later patient-level baseline analysis conceptually separate allows the study to use a close-to-assessment discovery rule without pretending that one short window is the only valid way to summarize a participant.

The observation-window decision was itself part of the proof of concept. Shorter and alternative windows were explored during development, while the present manuscript emphasizes the relationship between the first-valid 24-hour feature-finding rule and the broader availability-aware baseline analysis. The complete history of window testing remains available as supplementary analysis material.

### 2.5 Feature construction and manual curation

Raw records were converted into patient-level aggregate features. The feature library included measures of phone and application interaction, typing behavior, screen use, communication, touch behavior, activity states, network context, and other passive smartphone signals. Depending on the source, features represented event counts, the number of active hours, diversity, proportions, timing summaries, inter-event variability, or transitions between recorded states.

Each candidate feature was accompanied by a plain-language definition, source description, observation-window rule, coverage summary, and interpretation note. Missing values were retained as missing during descriptive analysis. A missing value was not silently converted into zero activity.

The manually curated feature set was deliberately narrower than the complete set of calculations generated during development. The purpose was to avoid presenting every technically calculable value as a meaningful phenotype component. Features were carried forward when their definition could be explained, their calculation could be reproduced, and their coverage was visible to the reader.

### 2.6 Coverage and missingness audit

Coverage was evaluated at table, feature, and participant levels. Table coverage described the proportion of participants for whom a source produced a usable result under the defined window rule. Feature missingness described the proportion of participants without an observed value for a feature. Participant-level summaries described how many usable features and source results were available for each person.

The analysis treated missingness as an observation property rather than as evidence of no behavior. The model preprocessing used training-fold imputation when a model required a complete matrix. The imputation rule was kept inside the training fold to reduce information leakage. Coverage and missingness summaries were reported separately from the imputed modeling matrix.

### 2.7 Exploratory feature screening

To create a clinically understandable exploratory table, participants were divided at the median baseline global cognitive score of 99.4. The lower-score group included 41 participants and the higher-score group included 40 participants. This split was used for description and hypothesis generation only; it was not a validated diagnostic or impairment threshold.

Continuous features were summarized using median and interquartile range. Two-sided Mann-Whitney U tests were used for feature-level comparisons where enough observations were available. Benjamini-Hochberg false-discovery-rate adjustment was applied across the feature-level tests. Cliff's delta was used to describe the direction and magnitude of group separation.

The five leading candidate features were ranked by nominal p-value and are presented in plain language in Table 1:

1. Median time required to complete a typed word.
2. Variability in the time between consecutive keyboard events, expressed as an interquartile range.
3. Number of missed, rejected, or blocked calls.
4. Total number of recorded call events.
5. Number of outgoing calls.

The first two candidates were observed in 62 and 66 participants, respectively. The three call-related candidates were observed in 14 participants each. All five were retained as exploratory candidates, but none was treated as a confirmed biomarker.

### 2.8 Patient-level models

The main model comparison used Ridge regression to estimate the continuous baseline global cognitive score. The primary feature scope contained 37 higher-coverage features selected during the curation process. Sensitivity scopes with broader feature sets were also evaluated, but the manuscript emphasizes the proof-of-concept comparison rather than presenting every model variant as a separate discovery.

All models were compared with the same fold-local mean baseline. Repeated five-fold cross-validation was performed for 20 repeats. Within each outer training fold, missing values were imputed using training-fold medians, missingness indicators were added for the primary Ridge run, and standardization parameters were learned from the training data. Ridge regularization was selected using four-fold inner cross-validation within each outer training fold.

Performance was summarized using root mean squared error, mean absolute error, and R-squared. The mean baseline was included because a digital phenotype should demonstrate value beyond the expected score for the cohort. The repeated predictions are resampling outputs and should not be interpreted as independent participant observations.

### 2.9 Candidate empirical score

As a traceable example of the feature-development process, the two keyboard candidates with the strongest nominal evidence were used to construct a narrow empirical score. The two features were oriented so that their observed directions aligned with higher baseline cognitive score, robustly scaled within the training fold, and entered into an equal-weight score and a direction-constrained Ridge model.

This candidate score was intentionally treated as exploratory. The two features were selected using the same cohort later used for model evaluation, so the result may be optimistic. The purpose was to show how a feature-level observation can be translated into a candidate patient-level estimate while preserving the distinction between discovery and validation.

### 2.10 Cognitive-domain analyses

Separate exploratory models were developed for memory, executive function, processing speed, attention, and motor performance. Domain-specific feature groups were defined using the behavioral interpretation of each feature. A feature could appear in more than one domain group when its meaning plausibly related to multiple cognitive processes.

Domain results were not assumed to be more valid than the global result. They were evaluated with the same attention to denominators, missingness, baseline comparison, and interpretability. Their final placement in the main text or supplementary material will depend on the final review of domain-specific coverage.

### 2.11 Data governance and reproducibility

The analysis generated separate, reviewable artifacts for feature definitions, patient-level data, coverage, missingness, model predictions, coefficients, and protocol notes. The Streamlit dashboard provides a human-readable view of these artifacts. The underlying participant-level records are not intended for public release.

**[TO COMPLETE: final code repository statement; data-access statement; privacy and de-identification language; reporting guideline selected for the target journal.]**

## 3. Results

### 3.1 What the computational experiment produced

The primary proof-of-concept output was an auditable chain from assessment-linked raw records to patient-level digital features and model estimates. The workflow produced a feature catalogue, patient-level matrices, coverage summaries, missingness summaries, descriptive comparison tables, model predictions, model metrics, and visual outputs. This made it possible to inspect not only the final estimate but also how much observed data supported each feature and each participant.

The process reduced a large collection of raw-table calculations and algorithm variants to a smaller interpretable library. This reduction was not a single automated selection step. It involved reviewing feature definitions, checking whether values had a meaningful behavioral interpretation, comparing coverage, identifying calculations that were too dependent on acquisition artifacts, and preserving the discarded candidates in the project record for later review.

### 3.2 Cohort and observation setting

The working cohort included 81 participants with observed baseline global cognitive scores. Median age was 80 years (IQR 77-83), 61 participants were female (75.3%), and median education was 15 years (IQR 13-17) among 80 participants with available education data. The median baseline global cognitive score was 99.4 (IQR 93.0-104.0).

The naturalistic setting produced unequal observation histories. Some participants contributed dense records across several behavioral sources, while others had sparse records for particular feature families. This heterogeneity was not a secondary technical detail; it determined which candidate features could be interpreted at patient level.

### 3.3 Coverage and missingness

Sixty-one measured digital features were included in the exploratory feature comparison, and 54 had completed metadata in the current catalogue. Across the source streams used for the working phenotype, coverage varied widely. The median source-level calculation rate was approximately 83%, while the mean was approximately 54%, reflecting a smaller number of sparse sources. Across all measured features, the median missingness was 13.6% and the mean was 37.6%.

This pattern showed why a single overall missingness number is insufficient. The typical feature was substantially better observed than the mean suggests, but a subset of low-coverage candidates could not be treated as if they were measured equally across participants. The analysis therefore kept coverage visible in the descriptive tables and model interpretation.

### 3.4 Five leading exploratory feature candidates

The feature-level screening produced five leading candidates. Table 1 reports their plain-language meaning, number of observed participants, nominal p-value, false-discovery-rate adjusted q-value, and direction of the group difference.

| Plain-language candidate | What it measures | Observed participants | Nominal p-value | FDR q-value | Direction in higher-score group |
|---|---|---:|---:|---:|---|
| Median typed-word completion time | Typical time inferred to complete a typed word from keyboard space transitions | 62 | 0.032 | 0.659 | Lower |
| Keyboard inter-event timing variability | Spread of the time intervals between consecutive keyboard observations | 66 | 0.036 | 0.659 | Lower |
| Missed/rejected/blocked call count | Number of call records with an unanswered or blocked status | 14 | 0.073 | 0.659 | Lower |
| Total call-event count | Number of recorded call-log events | 14 | 0.097 | 0.659 | Lower |
| Outgoing-call count | Number of recorded outgoing calls | 14 | 0.097 | 0.659 | Lower |

The two keyboard timing features had the smallest nominal p-values. Their group differences were directionally consistent with the higher-score group having lower timing values. However, the feature-level testing burden substantially reduced the adjusted evidence; both q-values were 0.659. The call-related candidates had sparse observations, making their nominal effect estimates less stable. These five features were therefore treated as candidates for replication and interpretation, not as established digital markers.

### 3.5 Baseline-referenced model results

The primary 37-feature Ridge model was close to the mean baseline. Across repeated cross-validation, the mean baseline had RMSE 8.532, MAE 6.797, and R-squared approximately 0. The Ridge model had RMSE 8.551, MAE 6.811, and R-squared -0.005. In practical terms, the curated feature set did not demonstrate a meaningful improvement over predicting the average baseline score for this cohort.

Broader feature scopes did not produce a consistent improvement. Some variants were numerically worse, particularly when lower-coverage features increased the complexity of the imputed matrix. These results are presented as a boundary of the current proof of concept rather than as evidence that passive smartphone sensing cannot contain cognitive information.

### 3.6 Traceable two-feature candidate score

The first candidate score used the two keyboard timing features with the strongest nominal screening results. The mean baseline had RMSE 8.664, MAE 6.912, and R-squared -0.032 in this separate exploratory run. The equal-weight score had RMSE 8.656, MAE 6.747, and R-squared -0.030. The direction-constrained Ridge estimate had RMSE 8.561, MAE 6.746, and R-squared -0.007.

The direction-constrained estimate was numerically closer to the observed score than the mean baseline, but the improvement was small and the overall fit remained weak. Only 62 participants had both keyboard candidates observed. This result demonstrates a complete candidate-feature-to-score workflow, but it does not establish clinical reliability.

### 3.7 Cognitive-domain outputs

Domain-specific analyses were generated for global cognition, memory, executive function, processing speed, attention, and motor performance. They showed the same general interpretive requirement as the global model: a domain plot must be read together with the number of observed participants, feature coverage, and the mean-baseline comparison.

**[TO COMPLETE: insert a short domain-level summary after final denominator and metric review. Detailed domain plots can be placed in the supplement.]**

## 4. Discussion

### 4.1 Principal proof-of-concept finding

The main result of this study is not a high-performing prediction model. It is the successful construction of a transparent process for turning heterogeneous passive smartphone records into patient-level digital phenotype candidates and testing their ability to estimate baseline cognition without hiding the limitations of the data.

The process produced a usable feature library, a visible coverage audit, a clinical-style exploratory comparison, baseline-referenced models, and a traceable path from candidate feature to candidate score. It also demonstrated that a large amount of engineering and analytic work does not guarantee a strong model. In this cohort, the primary curated model remained close to the mean baseline, and the two-feature candidate score produced only a small numerical improvement. This was an initial test of baseline-score estimation, not evidence of a clinically reliable score.

This is an appropriate proof-of-concept result. It shows that the workflow can answer the important preliminary questions: Which features can be calculated? Which participants have observations? What does each feature mean? How much information is lost to missingness? Do candidate models add value beyond the cohort mean? These questions must be answered before a digital phenotype can be described as clinically useful.

### 4.2 The importance of the analysis process

The work required substantially more than fitting a regression model. Raw records had to be linked to the correct participant and device, restricted to a reproducible time window, interpreted according to table-specific structure, summarized into patient-level variables, and audited for coverage. Hundreds of algorithmic calculations and variants were considered during development. Many were technically possible but not sufficiently interpretable or covered to be appropriate for the initial phenotype.

Manual feature curation was therefore a central part of the study. The final feature library was not simply the output of an automated ranking algorithm. It was assembled by considering behavioral meaning, data provenance, acquisition coverage, privacy, numerical stability, and usefulness for a clinical reader. This is an important distinction for digital phenotyping: the quality of a phenotype depends on the measurement definition and the acquisition context, not only on model performance.

At the same time, manual curation and repeated exploration create a risk of researcher degrees of freedom. The current paper addresses that risk by labeling outcome-informed screening and candidate-score construction as exploratory, retaining a common mean baseline, and documenting the analysis history. Future validation must separate feature selection from evaluation in a new cohort or a fully prespecified analysis.

### 4.3 Interpreting the five candidate features

The five leading candidates illustrate both the promise and the difficulty of this work. Keyboard timing measures have an intuitive connection to psychomotor and cognitive processing, and they were observed in more participants than the call-related candidates. Their nominal group differences therefore provide reasonable hypotheses for replication. However, the adjusted evidence was weak, and a feature-level group difference did not produce strong patient-level prediction.

The call-related candidates illustrate a different problem. Their nominal effect directions appeared potentially interesting, but only 14 participants had observed values. A large or consistent effect estimated from a very small observed subgroup cannot be treated as a stable digital marker. This is precisely why coverage should be displayed next to every feature result.

The two-feature candidate score was useful as a transparent demonstration of the modeling pathway. It was not chosen because it solved the clinical problem. It was chosen because the two keyboard features had the strongest nominal evidence and enough observations to permit a more interpretable exploratory test than the sparse call candidates. That choice must be validated independently before any clinical interpretation.

### 4.4 Why weak prediction is plausible

Several factors may explain why the model did not produce a strong fit. The cohort is small relative to the number of possible behavioral signals. The baseline cognitive score summarizes several abilities and may contain measurement variation that is not represented in passive phone data. The observation window summarizes behavior across an extended interval, which may reduce the relationship to the precise assessment date. Feature availability differs across participants, and imputation can reduce individual variation when observations are sparse.

In addition, the observed group comparison and the prediction problem are not the same task. The median split asks whether available feature distributions differ between two outcome-defined groups. Prediction asks whether the features can estimate a score for an individual whose outcome is not used to select the feature. The latter is more demanding and is the more relevant standard for a future digital phenotype score.

### 4.5 Coverage and missingness as scientific results

The coverage audit showed that passive sensing is not a single uniform measurement system. It is a collection of sources with different availability, sampling behavior, and failure modes. A meaningful patient-level phenotype must therefore report not just the feature value but also whether and how that value was observed.

The current results support a coverage-aware interpretation. The typical feature was reasonably observed, but a subset of features had very low availability. The mean missingness was consequently much higher than the median. This pattern can be hidden by a single imputation step, but it becomes visible when coverage is reported as part of the phenotype.

This does not mean that missing data should automatically be discarded. Missingness may itself carry information about device use or engagement, but treating it as a biological signal requires a separate, prespecified analysis. The current proof of concept keeps that distinction open and avoids claiming that missingness represents cognition.

### 4.6 Relationship to prior work

The study follows the logic of reproducibility and feasibility research. Large replication projects showed that careful measurement of variation and non-replication can be scientifically valuable [1,2]. A null gravitational-wave search demonstrated how a search with no confirmed detection can still produce useful limits and define what the data can rule out [3]. The present work is smaller and belongs to a different field, but it uses the same general principle: a transparent boundary on what the current data support is more informative than an overstated positive claim.

Digital health protocols increasingly separate technical feasibility, exploratory validity, and later clinical prediction [4]. Reviews of passive digital health studies also emphasize the need for better reporting of data quality, reference standards, missingness, and validation. The present workflow responds to those needs by making data acquisition and analysis history visible.

### 4.7 Clinical and research implications

The current output should not be used to diagnose dementia, classify an individual clinically, or replace cognitive assessment. Its immediate value is methodological. It provides a structured approach for deciding which passive features are sufficiently defined and observed to enter future validation studies.

The next study should increase the number of participants, improve the amount and consistency of baseline and follow-up data, prespecify the feature library before outcome testing, and evaluate any candidate feature direction in an independent sample. Additional sensor modalities can be added through the same process, but each must have a clear definition, coverage audit, and validation plan.

### 4.8 Strengths

Strengths include the retrospective naturalistic setting, explicit patient-level linkage, documentation of the feature-development process, manual curation based on meaning and coverage, preservation of missingness, use of a common mean baseline, training-fold preprocessing, and retention of exploratory outputs for audit. The work also makes the distinction between candidate discovery and clinical validation explicit.

### 4.9 Limitations

The cohort is small and drawn from one research setting. There is no external validation cohort or independent test set. The baseline window is a midpoint-anchored behavioral summary and may include behavior well after the assessment. Coverage varies across participants and features. The two-feature candidate score was selected using the same cohort used for evaluation, so its performance may be optimistic.

The current manuscript also depends on project decisions that must be frozen before submission, including the final diagnostic description, ethics statement, target journal, domain-result placement, and the exact definition of the primary feature library. The detailed history of all algorithm variants is too extensive for the main text and should be provided as a supplement or analysis appendix.

## 5. Future analysis plan

Before additional model experimentation, the study team should:

1. Confirm the cohort description, ethics information, and diagnostic composition.
2. Freeze the primary baseline window and outcome.
3. Freeze a plain-language feature dictionary containing each feature's definition, provenance, window, coverage, and privacy note.
4. Separate the primary analysis from outcome-informed exploratory screening.
5. Re-evaluate the five candidate features in a larger or independent sample.
6. Use nested or externally validated modeling when feature selection is part of the research question.
7. Report domain-specific results only with clear denominators and coverage summaries.
8. Preserve the complete algorithm and decision history as a supplementary reproducibility resource.

## 6. Conclusion

We developed and tested an auditable patient-level digital phenotyping workflow from passively collected smartphone and sensor records linked to standardized cognitive assessments. The project required extensive feature engineering, algorithm review, manual curation, coverage auditing, visualization, and baseline-referenced modeling. The current small cohort produced several exploratory feature candidates, including five leading candidates and a transparent two-feature keyboard model, but did not support a clinically reliable baseline-score estimate. The next objective is to test prediction of cognitive decline in a completed longitudinal analysis.

The central proof-of-concept finding is that rigorous data analysis can define the boundaries of a digital phenotype before clinical validation. A future validated phenotype will require more participants, more consistent acquisition, prespecified feature definitions, independent evaluation, and clear separation between exploratory discovery and confirmatory prediction.

## Declarations

### Ethics approval and consent to participate

**[TO COMPLETE.]**

### Consent for publication

**[TO COMPLETE.]**

### Availability of data and materials

Participant-level cognitive and smartphone records are not publicly available because of privacy and data-governance restrictions. De-identified aggregate outputs, feature definitions, analysis protocols, and code may be made available subject to institutional approval.

**[TO COMPLETE: final data-access wording and repository link.]**

### Competing interests

**[TO COMPLETE.]**

### Funding

**[TO COMPLETE.]**

### Authors' contributions

**[TO COMPLETE.]**

## References

1. Open Science Collaboration. Estimating the reproducibility of psychological science. *Science*. 2015. https://doi.org/10.1126/science.aac4716
2. Klein RA, et al. Many Labs 2: Investigating variation in replicability across samples and settings. *Advances in Methods and Practices in Psychological Science*. 2018. https://www.psychologicalscience.org/journals/ampps/2515245918810225/
3. Abbott BP, et al. All-sky search for continuous gravitational waves from isolated neutron stars in the early O3 LIGO data. 2021. https://arxiv.org/abs/2107.00600
4. SMART-A protocol for longitudinal feasibility and exploratory validation of digital measures in cognitive impairment. https://pmc.ncbi.nlm.nih.gov/articles/PMC13331333/
5. Multimodal passive smartphone sensing in older adults: a guide for clinical scientists based upon an ongoing cohort study. https://pubmed.ncbi.nlm.nih.gov/41853224/
6. Passive digital health technologies for cognitive and functional monitoring: systematic review. https://pmc.ncbi.nlm.nih.gov/articles/PMC13324020/
7. York DG, et al. The Sloan Digital Sky Survey: Technical Summary. *The Astronomical Journal*. 2000. https://www.sdss3.org/science/technical_publications.php

## Planned tables and figures

### Table 1. Five leading exploratory feature candidates

Use the plain-language feature descriptions in the Results section, with observed participants, nominal p-values, adjusted q-values, and a short interpretation of coverage.

### Table 2. Cohort and data-quality summary

Include participant count, age, sex, education, baseline cognitive score, number of measured features, feature metadata completeness, and summary coverage/missingness. Use one clear denominator for each item.

### Table 3. Primary model comparison

Compare the common mean baseline with the primary Ridge model. Present broader model variants as sensitivity analyses rather than as a series of competing discoveries.

### Figure 1. From passive records to a patient-level phenotype

Show assessment linkage, device mapping, observation-window construction, feature calculation, manual curation, coverage audit, and model evaluation.

### Figure 2. The analysis-development pathway

Show the progression from hundreds of feature calculations and quality-control checks to the curated feature library, exploratory candidate table, and baseline-referenced models.

### Figure 3. Observed versus estimated baseline cognition

Show the observed baseline cognitive ordering, the mean baseline, and the primary model estimate. Include a clear caption explaining that the plot demonstrates exploratory fit rather than clinical calibration.

### Supplementary material

Provide the complete feature dictionary, full feature-level comparison, domain plots, alternative observation-window results, model variants, coverage files, and the dated analysis decision log.
