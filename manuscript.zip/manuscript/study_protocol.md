# Working Study Protocol

## 1. Research question

Can passive smartphone and sensor data be transformed into a transparent, patient-level baseline digital phenotype that can be tested against baseline cognitive performance and later used in an exploratory attempt to predict cognitive decline?

## 2. Study design

This is an exploratory observational proof-of-concept and methods/feasibility study. It is not a clinical validation study and does not claim that the current output is ready for clinical decision-making.

## 3. Study objectives

### Objective 1: Create and test a baseline digital phenotype

Develop and audit an interpretable patient-level digital phenotype of baseline cognition from passive smartphone and sensor data, and conduct an exploratory test of whether the phenotype can estimate the participant's baseline cognitive score. Use the exploratory first-valid 24-hour observation found within the first week after baseline for feature finding, then apply finalized features to patient-level baseline analyses using a documented observation window.

### Objective 2: Explore prediction of cognitive decline

Explore whether the baseline digital phenotype and later changes in digital behavior between baseline and follow-up assessments can help predict decline in cognitive performance.

The present manuscript focuses on building and auditing Objective 1. Objective 2 is a planned exploratory longitudinal extension and is not presented as a completed or clinically validated result.

### Supporting analysis objective

Describe feature coverage, missingness, observation-window effects, and the relationship between digital features and baseline cognitive scores.

### Exploratory objective

Compare transparent regularized models and feature-group models with a common mean baseline, while reporting weak or null performance as an informative result.

## 4. Current cohort and observation windows

Feature finding uses the first valid 24-hour observation found within the first week after the baseline cognitive assessment. The main patient-level baseline analysis under consideration uses a patient-specific midpoint-anchored observation window. It begins at the baseline assessment and extends to the midpoint between the baseline and follow-up assessments. Patients without a valid follow-up assessment use the documented 123-day fallback midpoint. The exact primary cohort and analysis cutoff must be frozen after supervisor review.

Other completed windows, including short immediate windows, availability-anchored ten-day windows, baseline-to-follow-up change windows, and full-interval analyses, remain available as sensitivity or exploratory analyses. They should not all be presented as independent confirmatory tests.

Additional sensor modalities are treated as a separate analysis stream. Their role in the main manuscript must be decided after the feature review is complete.

## 5. Outcomes

- Primary candidate outcome: observed global cognitive T1 score.
- Secondary outcomes: available cognitive domains, including memory, executive function, processing speed, attention, and motor performance.
- Future outcome: T1-to-T2 cognitive change, if the longitudinal analysis is frozen and sufficiently complete.

## 6. Feature and data-quality rules

- Features are calculated at patient level from documented time windows.
- Missingness and coverage are retained as explicit audit outputs.
- Missing data are not silently interpreted as zero activity.
- Modeling imputation, when used, is performed within the training fold to avoid leakage.
- Feature selection based on the same cohort as model evaluation is labeled exploratory and potentially optimistic.

## 7. Modeling rules

- Every model is compared against the same fold-local mean baseline.
- Ridge or other regularized models are preferred because the cohort is small relative to the feature space.
- Performance is reported with RMSE, MAE, and R-squared, together with calibration or observed-versus-estimated plots where appropriate.
- A weak model is not described as a clinical digital phenotype score.
- No clinical threshold, diagnostic claim, or external validity claim is made without independent validation.

## 8. Reporting rules

The manuscript will report the complete analysis path, including coverage limitations, missingness, nominal findings that do not survive multiplicity correction, model results that do not outperform the baseline meaningfully, and analyses retained only for future work.

## 9. Decisions required before manuscript freeze

1. Confirm the primary cohort and observation window.
2. Confirm whether global T1 is the sole primary outcome.
3. Decide which domain analyses belong in the main paper and which belong in the supplement.
4. Decide whether supplemental modalities are included in the initial manuscript.
5. Freeze the primary feature catalog and model comparison.
6. Confirm the intended target journal and reporting checklist.
