# Manuscript Figures

Store publication-ready figures here after the primary analysis is frozen.

Planned main figures:

1. Raw passive smartphone records to patient-level digital phenotype pipeline.
2. Feature and table coverage/missingness overview.
3. Observed versus estimated baseline cognition against the common mean baseline.

Exploratory domain plots, window comparisons, and additional model graphs should be labeled as supplementary unless the primary protocol is changed and documented.

## 2026-10-26 frozen top-15 evidence figures

- `figure_primary_secondary_forest_v1.png` / `.pdf`: discovery and recording-adjusted estimates for the frozen six-signal keyboard set; the afternoon 12–18 IEI/Executive Function signal is highlighted as the primary exploratory POC.
- `figure_top15_evidence_map_v1.png` / `.pdf`: all 15 reconstructed estimates with 95% confidence intervals and primary/secondary/supplementary classification.
- `figure_primary_poc_coverage_audit_v1.png` / `.pdf`: patient-level primary-POC pairs, feature-versus-coverage change, within-patient active-day shifts, and early/late snapshot-volume comparison.

Source script: `scripts/create_top15_article_figures_v1.py`.
