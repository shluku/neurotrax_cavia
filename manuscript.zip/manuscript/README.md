# Research Manuscript Workspace

This folder is the working source of truth for the first research manuscript.

## Working study frame

**Working title:** Building and Testing an Auditable Patient-Level Digital Phenotype of Cognition from Passive Smartphone Sensing

**Study type:** Exploratory observational proof-of-concept and methods/feasibility study.

## Study objectives

1. Create and test an interpretable, coverage-aware patient-level baseline digital phenotype from passive smartphone data, including exploratory estimation of the baseline cognitive score.
2. Explore whether digital phenotyping can help predict cognitive decline in a later longitudinal analysis.

**Central message:**

> In a small, heterogeneous dementia cohort, we developed and audited a patient-level digital phenotyping pipeline linking passive smartphone data with baseline cognitive performance. The study demonstrates the practical challenges of coverage, missingness, feature-window selection, and model interpretability. Exploratory feature associations were observed, but they did not yet produce a clinically reliable prediction model. These results define the requirements for future, better-powered validation studies.

This is a working research frame, not a claim of clinical validation. The manuscript must distinguish primary analyses, exploratory analyses, and future work.

## Files

- `study_protocol.md`: current study scope and analysis commitments.
- `manuscript_outline.md`: proposed approximately 10-page structure.
- `evidence_register.csv`: claims linked to project outputs and limitations.
- `analysis_decisions.md`: dated decisions and unresolved questions.
- `section_status.csv`: writing and analysis progress tracker.
- `draft_v01.md`: current working manuscript draft; it is not yet submission-ready.
- `references.md`: working bibliography to verify before submission.
- `figures/` and `tables/`: planned publication artifacts and source notes.

## Operating rule

Streamlit displays this workspace, but these files remain the editable source of truth. New analyses should be added to the evidence register before being promoted into the main manuscript. Existing project phases remain unchanged.


## Complete saved-results review — 2026-10-20

See the [existing project handoff review](../README_PROJECT_HANDOFF.md#complete-historical-research-review--2026-10-20) for the 40-workstream chronology, ranked direct correlations, separate predictive comparison and unresolved reporting defects. Source-linked evidence tables are in `tables/research_review_*_20261020.csv`. The saved-prediction-only [model-results audit](../output/analysis_candidates/model_results_audit_20261020/README_model_results_audit.md) now replaces invalid legacy pooled metrics with patient-aligned metrics without retraining. It identifies the n=71 Processing-speed/10-day Ridge as the most credible *exploratory* historical prediction candidate; it is a post-T1 concurrent model and has no independent validation. The n=10 Global elastic-net result remains descriptive. Afternoon keyboard interval change remains an exploratory EF candidate.

The [Master Association Table](tables/master_association_table_20261020.csv) contains every saved direct individual feature–cognition estimate, including non-significant and superseded sensitivity results. Its 1,871 rows must not be interpreted as independent discoveries: FDR families are source-specific and repeated windows/adjustments refer to overlapping cohorts. The only manuscript POC candidate supported by a comprehensive screen and recording-adjusted sensitivity is afternoon snapshot-interval change versus executive-function change; it remains exploratory and unconfirmed.
## Current top-15 article drafting artifacts

- [Top-15 interpretation and limitations draft](top15_interpretation_limitations_20261026.md)
- [Current gap register](current_gap_register_20261026.md)
- [Primary POC device/coverage audit](primary_poc_device_coverage_audit_20261026.md)
- [Supplementary robustness inventory](supplementary_robustness_inventory_20261026.md)
- [Prediction results audit](prediction_results_audit_20261026.md)
- [Unsupported supplementary-row retention audit](supplementary_row_retention_audit_20261026.md)
- [Manuscript figures](figures/README.md)
