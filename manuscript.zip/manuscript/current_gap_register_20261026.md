# Current research and article gap register — 2026-10-26

This file is the active handoff context for the manuscript and critical data review. It records unresolved gaps after freezing the top-15 evidence hierarchy.

## Article-production gaps

1. Coverage adjustment is uneven: full technical/recording adjustment exists for the six prespecified keyboard signals; the remaining nine have focused recording-density sensitivity analyses only. Device-change fields are unavailable in some reconstructed cohorts.
2. Robustness and reliability are uneven: four of the nine supplementary rows have saved leave-one-out, outlier, and permutation checks, but five rows lack equivalent robustness evidence and none has independent validation or complete test–retest evidence.
3. Figures are partly complete: the forest plot, top-15 evidence map, and primary-POC scatter/coverage audit now exist; final manuscript placement and any additional supplementary distribution plots remain.
4. Interpretation is drafted but must be integrated into the manuscript Results and Discussion.
5. Prediction reporting now has a separate audited draft with matched mean-baseline comparisons and explicit preprocessing/nesting limitations; integration into the main manuscript remains.

## Scientific and data gaps

6. No independent participant cohort, temporal holdout, or external replication exists.
7. Snapshot-derived IEIs are not direct keystroke timing; word-completion measures have additional continuity, edit-state, paste/prediction, and boundary limitations.
8. Several findings use small cohorts, and some windows were selected after exploratory review.
9. Top-15 q-values do not provide project-wide FDR control; their source or reconstructed testing family must remain visible.
10. Device episodes, app composition, active days, snapshot density, and valid-interval density may still explain part of the patient-level associations. A descriptive primary-POC device/coverage audit is now saved, but the device-unchanged subgroup is only n=6 and cannot validate the signal.
11. Phase 7 10-day extraction remains unintegrated into the article evidence hierarchy.

## New priority from the coverage audit

- In the primary POC patient-level audit (n=28), afternoon IEI change was inversely associated with change in afternoon active days (Spearman ρ=-.489, p=.0082), while 22/28 participants had a device-set change. This does not invalidate the association, but it makes coverage/device composition a central competing explanation that must be shown and discussed before any behavioral interpretation.

## Addressed in the current pass

- Frozen primary POC, secondary six-signal set, and supplementary nine-row set.
- Saved interpretation/limitations draft.
- Primary/secondary forest plot and top-15 evidence map.
- Patient-level primary-POC and coverage audit figure completed; manuscript placement remains.
- Supplementary robustness inventory completed; it distinguishes four rows with saved exploratory checks from five rows with no comparable robustness output.
- Prediction-results separation drafted; the five unsupported supplementary rows were classified for supplement/coverage material rather than main-text promotion.
