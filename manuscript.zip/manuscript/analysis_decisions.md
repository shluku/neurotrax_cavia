# Analysis Decisions Log

This log records decisions that affect the manuscript. It is intentionally separate from the exploratory phase protocols.

## 2026-08-17: Initial manuscript frame

- Position the work as an exploratory observational proof-of-concept and methods/feasibility study.
- Make coverage, missingness, window selection, and interpretability central scientific results.
- Do not present the current model as a clinically validated digital phenotype score.
- Use the mean baseline as the common comparator for model claims.
- Keep all previous project phases intact; select a frozen subset for the main manuscript and report the rest as sensitivity or exploratory analyses.

## Open decisions for supervisor review

- Primary cohort: midpoint-anchored baseline window, short immediate window, or another prespecified cohort.
- Primary outcome: global T1 only or global T1 plus selected cognitive domains.
- Role of baseline-to-follow-up change and full-interval analyses in the first manuscript.
- Whether additional sensor modalities are mature enough for the initial paper.
- Main-paper versus supplement allocation for the many exploratory models.
- Target journal and reporting checklist.

## 2026-08-17: First working draft

- Draft v0.1 was written from the current midpoint-anchored baseline, clinical-style comparison, Ridge, and exploratory empirical outputs.
- Exact cohort, coverage, and model values were inserted where available.
- Ethics, diagnostic composition, journal choice, domain-result placement, and data-access language remain explicitly marked for supervisor confirmation.
- The draft treats the current digital phenotype as a candidate framework, not a validated clinical score.

## 2026-08-17: Reader-facing revision

- Replace internal database and project-stage names with descriptive terms.
- Expand the retrospective naturalistic computational setting and the multi-month feature-engineering workflow.
- Present five plain-language exploratory feature candidates while keeping the two-feature score explicitly exploratory.
- Make the Results proof-of-concept driven and avoid listing specific data sources as exclusions.

## Interpretation guardrails

- Nominal p-values are not treated as confirmed discoveries after multiplicity correction.
- A model with a small numerical improvement but poor absolute fit remains exploratory.
- Missingness is not automatically a biological signal.
- “First of its kind” should only be used after a formal literature review; otherwise use “to our knowledge” cautiously.


## 2026-10-20 — Repository-wide historical review (documentation only)

- Preserve all original analyses. Review only saved results and code; no new inference or model fitting.
- Rank distinct direct feature–cognition pairs by largest observed absolute coefficient, retaining and marking superseded estimates; retain a separate repeated-estimate table. Do not rank PCA loadings or cluster effect sizes as feature correlations.
- Do not promote legacy pooled baseline-family metrics: source uses tiled original outcomes against fold-ordered predictions. Source inspection and saved ordering confirm the mismatch. Summarize aligned saved per-repeat rows pending a separate authorized correction.
- Highest saved aligned mean R² is top10 Global elastic net (n=10, .2657), considered descriptive; larger-cohort candidates are processing-speed10-day Ridge (n=71,.0799) and Motor24h Ridge (n=79,.0559). Fully nested preprocessing and independent confirmation remain needed.
- Prioritize afternoon snapshot-interval/EF change for a prespecified validation hypothesis, not the n=18 maximum. Do not tune thresholds/windows for stronger correlations.
- Distinguish within-six-signal q-values, discovery-screen q-values and corrected 270-test q-values. Note the raw/partial mismatch in historical thirds CI/q comparison.
- Current best manuscript claim remains measurement feasibility with coverage-sensitive structure and exploratory, unvalidated cognitive findings.
- Full review and source tables: [project handoff](../README_PROJECT_HANDOFF.md#complete-historical-research-review--2026-10-20), [tables index](tables/README.md).

## 2026-10-20 — Saved-prediction metric correction and model freeze

- `audit_historical_model_results.py` recalculated reporting metrics from correctly paired saved prediction rows only. It did not fit or tune a model. Outputs are versioned under [model_results_audit_20261020](../output/analysis_candidates/model_results_audit_20261020/README_model_results_audit.md); original historical metrics remain unchanged.
- The invalid historical pooled outcome vector (`np.tile(y, repeats)`) is replaced for reporting by row-aligned pooled and per-repeat values. All three audited sets have exactly one saved prediction per participant/repeat and complete agreement between saved actual outcomes and their source patient tables.
- Freeze the one confirmatory target: Processing Speed T1; n=71; first-available 10-day window after T1; fixed 37-feature primary panel; Ridge versus a fold-matched mean baseline. It has corrected repeat-mean RMSE 12.950 versus 13.718 and R² .0799 versus −.0278. The conditional patient-cluster bootstrap interval for RMSE improvement is −1.13 to 2.37, so it does not demonstrate reliable superiority. It remains exploratory, and its post-T1 feature window is concurrent with—not predictive of—the T1 outcome.
- Motor/24-hour Ridge is a secondary exploratory candidate (n=79; RMSE 10.186 vs 10.678). Global coverage top-10 Elastic Net is descriptive only (n=10; RMSE 7.978 vs 10.454) because model/cohort search and tiny sample prevent a primary claim.
- A future confirmation must use new held-out participants and a fully nested pipeline that fits imputation/scaling inside every inner tuning split, with feature eligibility, the 37 features, outcome and reporting fixed before outcomes are examined. Do not reconstruct candidate feature contributions: no fold-level coefficients or attribution outputs were saved.

## 2026-10-20 — Master association catalog and manuscript POC boundary

- `build_master_association_table.py` creates a saved-results-only catalog of 1,871 direct individual digital-feature–cognition estimates from ten source outputs. It adds the Phase 11 61-feature Global-T1 group contrasts to the earlier 1,810 correlation catalog. It does not recompute any association.
- Treat the 154 p<.05 rows, 40 q<.05 rows and 62 q≤.20 rows as overlapping estimate rows, not discovery counts. FDR is valid only within the source-specific testing family recorded in the master table. Historical thirds raw-row adjustments are retained but labeled superseded.
- Use afternoon snapshot-interval change versus executive-function change as the sole exploratory association POC: discovery ρ=.592856, n=28, q=.090318; recording-adjusted partial ρ=.507994, q=.133256; corrected-thirds q=.835982. Report all three stages together.
- Do not promote the restricted n=18 morning-interval/attention maximum, raw Phase 11 p<.05 keyboard group contrasts, supplemental coverage-volume correlations, PCA overlays or model coefficients as feature discoveries. Touch, screen, app and motion features have no saved direct correlation screen that yields a current FDR-supported candidate.

## 2026-10-21 — Complete feature/cognitive register and technical qualifications

- Add a versioned dictionary and complete evidence register within the existing manuscript tables. Preserve every original catalog record/version and all 1,871 master estimates. The new register has 2,560 saved estimates; its 216 p<.05 rows and 52 q<.05 rows are repeated evidence, not independent discovery counts. Do not pool source-specific FDR families or impute missing inferential statistics.
- Keep exact p-values as the primary display metric. Preserve raw source precision, coefficient type, outcome coding, window, n, CI provenance, and links to the original CSV row. Distinguish cognitive-group Cliff's delta from correlations; the formerly uncataloged 61-feature extreme-score contrast is now included.
- Keep the six selected keyboard discovery candidates as exploratory hypotheses with adjustment/reliability/sensitivity evidence attached. Afternoon IEI/EF falls to partial rho .3560589268542629, p .11315185142672757 after all audited technical factors. This supersedes any interpretation of it as a robust behavioral speed marker, without altering its original saved estimates.
- Qualify Word Completion Timing v1 before manuscript use: final unadjusted screen is 270 rows, adjusted screen 263 rows without q/CI; inter-snapshot continuity and genuinely observed first-character onset are not verified. Edits-state resets, paste/prediction ambiguity, zero durations, ISO-week grouping and saved password-filter provenance require clarification. Daily variability is not test–retest reliability. The n=27 versus n=28 comparison does not use identical patients.
- Retain the adjusted word-IQR/Global-change partial rho .5249247963140329, p .0041305973834450385, n=31 as an uncorrected exploratory observation requiring technical clarification; do not attach its unadjusted q or CI. No new statistical analyses, extraction, model training, or general-model integration was performed.
- Follow the candidate-specific [validation roadmap](tables/poc_validation_roadmap_20261021_v1.csv) and [handoff section](../README_PROJECT_HANDOFF.md#complete-feature-dictionary-cognitive-findings--poc-validation-roadmap). Preserve the existing research freeze. Technical validation precedes any future word-feature cognitive reanalysis; independent participants are required for confirmation.

## 2026-10-26 — Top-15 evidence hierarchy freeze

- Freeze afternoon snapshot inter-event-interval change versus Executive Function change as the sole primary exploratory association POC. The saved discovery estimate is rho=.592856, n=28, q=.090318; the recording-adjusted estimate is partial rho=.507994, q=.133256. The corrected-thirds result is weaker and remains part of the qualification, not a separate discovery.
- Classify the other five prespecified longitudinal keyboard signals as secondary exploratory analyses. They retain the shared six-signal adjustment, leave-one-out, permutation, reliability, and alternate-window evidence, but none is independently validated.
- Classify the remaining nine top-15 rows as supplementary exploratory sensitivity analyses: restricted-window rows, baseline word-completion rows, the morning IEI-IQR/Executive Function row, and legacy trimmed T1 rows. Their focused recording-density adjustments do not upgrade them to validated findings; small n, window selection, measurement-proxy limitations, and incomplete reliability remain material.
- Keep correlation evidence separate from the audited Ridge/Elastic Net prediction results. The prediction analyses remain a separate exploratory modeling section with mean-baseline comparisons.
- The complete top-15 set has no independent cohort, temporal holdout, or external replication. No result should be described as a validated digital biomarker.
