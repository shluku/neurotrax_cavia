# Manuscript Tables

Planned main tables:

1. Cohort and cognitive assessment characteristics.
2. Feature and table coverage/missingness summary.
3. Primary model comparison against the mean baseline.

The complete feature-level clinical-style comparison and exploratory model outputs should be retained as supplementary material or an analysis appendix unless the supervisor approves otherwise.


## Historical review tables — 2026-10-20

These tables copy/catalog saved statistics or summarize already-saved per-repeat metrics; no new correlations, p-values, FDR, bootstraps or model metrics were calculated. `NR`/blank values indicate unavailable matching statistics. The narrative remains in the [project handoff](../../README_PROJECT_HANDOFF.md#complete-historical-research-review--2026-10-20).

- [research_review_all_saved_direct_correlations_20261020.csv](research_review_all_saved_direct_correlations_20261020.csv)
- [research_review_chronology_20261020.csv](research_review_chronology_20261020.csv)
- [research_review_document_script_index_20261020.csv](research_review_document_script_index_20261020.csv)
- [research_review_saved_repeat_model_summary_20261020.csv](research_review_saved_repeat_model_summary_20261020.csv)
- [research_review_saved_result_inventory_20261020.csv](research_review_saved_result_inventory_20261020.csv)
- [research_review_top10_correlations_20261020.csv](research_review_top10_correlations_20261020.csv)
- [research_review_top10_estimates_including_repeat_pairs_20261020.csv](research_review_top10_estimates_including_repeat_pairs_20261020.csv)

## Master Association Table — 2026-10-20

The [Master Association Table](master_association_table_20261020.csv) catalogs 1,871 saved direct individual digital-feature–cognition estimates from ten source outputs. It preserves original versus sensitivity status, FDR family context, coverage-adjustment context, missing statistics and superseded historical estimates. It is a cataloging output; no association was recalculated.

- [Master table](master_association_table_20261020.csv)
- [p < .05 rows](master_associations_p_lt_0_05_20261020.csv)
- [FDR q < .05 rows](master_associations_fdr_q_lt_0_05_20261020.csv)
- [FDR q ≤ .20 rows](master_associations_fdr_q_le_0_20_20261020.csv)
- [POC candidate representatives](master_association_poc_candidates_20261020.csv)
- [Master-table summary and missing-statistics counts](master_association_summary_20261020.csv)
- [Excluded derived-output classes](master_association_excluded_output_classes_20261020.csv)

## Complete feature and cognitive findings register — 2026-10-21

The dedicated methods, caveats, supervisor summary and validation roadmap are in [README_PROJECT_HANDOFF.md](../../README_PROJECT_HANDOFF.md#complete-feature-dictionary-cognitive-findings--poc-validation-roadmap). This additive register preserves the earlier Master Association Table and every historical definition. It catalogs saved results only.

- [Detailed feature dictionary: 1,246 version records / 496 exact names](complete_feature_dictionary_20261021_v1.csv)
- [Complete association register: 2,560 saved estimates](complete_feature_cognitive_associations_20261021_v1.csv)
- [All p<.05 records: 216 estimates, not independent discoveries](complete_feature_cognitive_p_lt_0_05_20261021_v1.csv)
- [14-row supervisor findings table](supervisor_feature_findings_20261021_v1.csv)
- [Candidate-specific validation roadmap](poc_validation_roadmap_20261021_v1.csv)
- [Statistical-source inventory](feature_findings_source_inventory_20261021_v1.csv)
- [Counts and immutable source-hash manifest](complete_feature_findings_manifest_20261021_v1.json)

P-values are the primary display field and preserve exact source decimal strings. Q-values and confidence intervals apply only to their matching estimator/testing family. Blank cells mean unavailable, not zero. Repeated windows, selected-signal adjustments, permutation results and superseded versions remain linked and explicitly labeled. All 52 q<.05 rows originate from selected-signal/restricted follow-ups; no project-wide FDR or independent replication is implied. Derived PCA/cluster associations and predictive metrics remain separate.

Word Completion Timing v1 is included with a technical-clarification flag: the saved screen has 270 rows, adjusted q/CI are absent, sequence continuity is unverified, saved password-filter provenance is unresolved, and the comparison named matched uses n=27 versus n=28. Earlier summaries are retained as history; use the new handoff section for these qualifications.

## Candidate evidence completeness audit — 2026-10-21

This versioned, candidate-specific audit reuses saved patient/window outputs for K1–K6, the legacy word proxy (W1), and Word Completion v1 IQR change (W2). New calculations are descriptive distributions and exploratory OLS-per-feature-IQR summaries only; no broad search, model training, or historical output was changed. Repeated same-cohort sensitivity results are not independent replication.

- [Candidate Evidence Completeness Table](../../output/analysis_candidates/keyboard_deep_dive_v1/candidate_evidence_completeness_20261021/candidate_evidence_completeness_table_20261021_v1.csv)
- [Descriptive distributions](../../output/analysis_candidates/keyboard_deep_dive_v1/candidate_evidence_completeness_20261021/candidate_evidence_descriptive_distributions_20261021_v1.csv)
- [Source index and testing context](../../output/analysis_candidates/keyboard_deep_dive_v1/candidate_evidence_completeness_20261021/candidate_evidence_source_index_20261021_v1.csv)
- [Versioned audit methods and validation plan](../../output/analysis_candidates/keyboard_deep_dive_v1/candidate_evidence_completeness_20261021/README_candidate_evidence_completeness.md)
